
package Class;

public class CUADROT {
    public int NResidente=500;
    public int Residente=0;
    public int Horas=0;
    public int[] Antiguedad = new int[NResidente];      
    public  String [] Nombre = new String [NResidente];
    public  String [] Documento = new String [NResidente];        
    public  int[] Electiva = new int[NResidente];
    public  int[] Especialidad = new int[NResidente];
    public  int[] Rotacion = new int[NResidente];
    public  int[] Turno_Nocturno = new int[NResidente];
    public  int[][] No_turno = new int[NResidente][32];
    public  int[][] Refuerzo = new int[NResidente][32];
    public int [] Semanas_Junio ={0,1,8,15,22,29};
    public int [] SabadosJ = {1,8,15,22,29};
    public int [] DomingoJ = {2,9,16,23,30};
    public int [] Semanas_Julio ={0,1,8,15,22,29};
    public int [] SabadosJl = {6,13,20,27};
    public int [] DomingoJl = {7,14,21,28};
    public int [] Semanas_Agosto ={0,1,8,15,22,29};
    public int [] SabadosA = {3,10,17,24,31};
    public int [] DomingoA = {4,11,18,25};
    
    
    
      
      
}
