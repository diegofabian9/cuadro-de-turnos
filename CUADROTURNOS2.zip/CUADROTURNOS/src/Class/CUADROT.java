
package Class;

public class CUADROT {
    public String Nombre;
    public String Documento;
    public String No_turno;
    public String Refuerzo;
    public String Antiguedad;
    
    
    public  String[][] turno = new String[0][0];
    public  String[][] refuerzo = new String[0][0];
    
}
